/****************************************************************************/
/*  File:       LoggerHelper.java                                           */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-08-04                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import java.util.Iterator;
import org.apache.commons.logging.Log;
import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.NameValuePair;
import org.apache.http.cookie.Cookie;
import tmp.tests.ArrayIterator;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-08-04
 */
public class LoggerHelper
{
    public static void logCookies(Log log, String prompt, Iterable<Cookie> cookies)
    {
        logCookies(log, prompt, cookies.iterator());
    }

    public static void logCookies(Log log, String prompt, Cookie[] cookies)
    {
        logCookies(log, prompt, new ArrayIterator<Cookie>(cookies));
    }

    public static void logCookies(Log log, String prompt, Iterator<Cookie> cookies)
    {
        if ( log.isDebugEnabled() ) {
            if ( cookies == null ) {
                log.debug(prompt + ": null");
                return;
            }
            while ( cookies.hasNext() ) {
                Cookie c = cookies.next();
                log.debug(prompt + ": " + c.getName() + ": " + c.getValue());
            }
        }
    }

    public static void logHeaders(Log log, String prompt, Iterable<Header> headers)
    {
        logHeaders(log, prompt, headers.iterator());
    }

    public static void logHeaders(Log log, String prompt, Header[] headers)
    {
        logHeaders(log, prompt, new ArrayIterator<Header>(headers));
    }

    private static void logHeaders(Log log, String prompt, Iterator<Header> headers)
    {
        if ( log.isDebugEnabled() ) {
            if ( headers == null ) {
                log.debug(prompt + ": null");
                return;
            }
            while ( headers.hasNext() ) {
                Header h = headers.next();
                log.debug(prompt + ": " + h.getName() + ": " + h.getValue());
            }
        }
    }

    public static void logHeaderDetails(Log log, String prompt, Iterable<Header> headers)
    {
        logHeaderDetails(log, prompt, headers.iterator());
    }

    public static void logHeaderDetails(Log log, String prompt, Header[] headers)
    {
        logHeaderDetails(log, prompt, new ArrayIterator<Header>(headers));
    }

    public static void logHeaderDetails(Log log, String prompt, Iterator<Header> headers)
    {
        if ( log.isDebugEnabled() ) {
            if ( headers == null ) {
                log.debug(prompt + ": null");
                return;
            }
            while ( headers.hasNext() ) {
                Header h = headers.next();
                log.debug(prompt + " - HEADER: " + h.getName() + ": " + h.getValue());
                for ( HeaderElement e : h.getElements() ) {
                    log.debug(prompt + " -   ELEM: " + e.getName() + ": " + e.getValue());
                    for ( NameValuePair p : e.getParameters() ) {
                        log.debug(prompt + " -     P: " + p.getName() + ": " + p.getValue());
                    }
                }
            }
        }
    }
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
