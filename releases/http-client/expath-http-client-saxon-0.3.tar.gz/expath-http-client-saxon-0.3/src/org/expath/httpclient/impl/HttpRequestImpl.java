/****************************************************************************/
/*  File:       HttpRequestImpl.java                                        */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-02                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.trans.XPathException;
import org.apache.http.Header;
import org.expath.httpclient.ContentType;
import org.expath.httpclient.HeaderSet;
import org.expath.httpclient.HttpRequestBody;
import org.expath.httpclient.HttpConnection;
import org.expath.httpclient.HttpCredentials;
import org.expath.httpclient.HttpRequest;
import org.expath.httpclient.HttpResponse;
import org.expath.httpclient.HttpResponseBody;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-02
 */
public class HttpRequestImpl
        implements HttpRequest
{
    public HttpRequestImpl(XPathContext ctxt)
    {
        myCtxt = ctxt;
    }

    public HttpResponse send(HttpConnection conn, XPathContext ctxt, HttpCredentials cred)
            throws XPathException
    {
        if ( myHeaders == null ) {
            myHeaders = new HeaderSet();
        }
        conn.setRequestMethod(myMethod);
        conn.setRequestHeaders(myHeaders);
        conn.connect(myBody, cred);
        int status = conn.getResponseStatus();
        String msg = conn.getResponseMessage();
        HttpResponseBody body = null;
        if ( ! myStatusOnly ) {
            ContentType type = null;
            if ( myOverrideType == null ) {
                Header h = conn.getResponseHeaders().getFirstHeader("Content-Type");
                // If there is no Content-Type, we assume there is no content.
                if ( h != null ) {
                    type = new ContentType(h);
                }
            }
            else {
                type = new ContentType(myOverrideType, null);
            }
            if ( type != null ) {
                body = BodyFactory.makeResponseBody(type, conn, ctxt);
            }
        }
        return new HttpResponse(myCtxt, status, msg, conn.getResponseHeaders(), body);
    }

    public String getMethod()
    {
        return myMethod;
    }

    public void setMethod(String method)
    {
        myMethod = method;
    }

    public String getHref()
    {
        return myHref;
    }

    public void setHref(String href)
    {
        myHref = href;
    }

    public void setContent(Item content)
    {
        myBody.setContent(content);
    }

    public void setSerial(Item serial)
    {
        myBody.setSerial(serial);
    }

    public void setOverrideType(String type)
    {
        myOverrideType = type;
    }

    public void setHeaders(HeaderSet headers)
    {
        myHeaders = headers;
    }

    public void setBody(HttpRequestBody body)
            throws XPathException
    {
        myBody = body;
        body.setHeaders(myHeaders);
    }

    public void setStatusOnly(boolean only)
    {
        myStatusOnly = only;
    }

    private XPathContext myCtxt;
    private String myMethod;
    private String myHref;
    private String myOverrideType;
    private boolean myStatusOnly;
    private HeaderSet myHeaders;
    private HttpRequestBody myBody;
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
