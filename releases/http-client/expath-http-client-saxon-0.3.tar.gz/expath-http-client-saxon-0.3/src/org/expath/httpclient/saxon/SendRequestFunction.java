/****************************************************************************/
/*  File:       SendRequestFunction.java                                    */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-08-08                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.saxon;

import net.sf.saxon.Configuration;
import net.sf.saxon.expr.StaticProperty;
import net.sf.saxon.functions.ExtensionFunctionCall;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.pattern.NameTest;
import net.sf.saxon.type.AnyItemType;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.SequenceType;
import org.expath.httpclient.HttpConstants;
import org.expath.pkg.saxon.EXPathFunctionDefinition;

/**
 * TODO: Doc...
 *
 * @author Florent Georges
 * @date   2009-08-08
 */
public class SendRequestFunction
        extends EXPathFunctionDefinition
{
    @Override
    public void setConfiguration(Configuration config)
    {
        myConfig = config;
    }

    @Override
    public StructuredQName getFunctionQName()
    {
        final String uri    = HttpConstants.HTTP_CLIENT_NS_URI;
        final String prefix = HttpConstants.HTTP_CLIENT_NS_PREFIX;
        return new StructuredQName(prefix, uri, LOCAL_NAME);
    }

    @Override
    public int getMinimumNumberOfArguments()
    {
        return 1;
    }

    // TODO: First only support the 1-parameter version.
//    @Override
//    public int getMaximumNumberOfArguments()
//    {
//        return 4;
//    }

    // TODO: First only support the 1-parameter version.
    @Override
    public SequenceType[] getArgumentTypes()
    {
        final int      one   = StaticProperty.EXACTLY_ONE;
//        final ItemType itype       = new RequestType();
        final int      kind  = Type.ELEMENT;
        final String   uri   = HttpConstants.HTTP_CLIENT_NS_URI;
        final NamePool pool  = myConfig.getNamePool();
        final ItemType itype = new NameTest(kind, uri, "request", pool);
        SequenceType   stype = SequenceType.makeSequenceType(itype, one);
        return new SequenceType[]{ stype };
    }

    @Override
    public SequenceType getResultType(SequenceType[] params)
    {
        final int      more  = StaticProperty.ALLOWS_ONE_OR_MORE;
        final ItemType itype = AnyItemType.getInstance();
        return SequenceType.makeSequenceType(itype, more);
    }

    @Override
    public ExtensionFunctionCall makeCallExpression()
    {
        return new SendRequestCall();
    }

    private static final String LOCAL_NAME = "send-request";
    private Configuration myConfig;

//    /**
//     * An ItemType representing an element with its name.
//     *
//     * Correspond to the NodeKind expression {@code element(ns:name)}.  Saxon
//     * has the class {@link net.sf.saxon.pattern.NameTest}, but it requires a
//     * {@link net.sf.saxon.om.NamePool} object.  This one does not.
//     */
//    private class RequestType
//            extends NodeTest
//    {
//        @Override
//        public boolean isAtomicType()
//        {
//            return false;
//        }
//
//        @Override
//        public boolean matchesItem(Item item, boolean allowURIPromotion, Configuration config)
//        {
//            if ( ! ( item instanceof NodeInfo ) ) {
//                return false;
//            }
//            NodeInfo node = (NodeInfo) item;
//            if ( node.getNodeKind() != Type.ELEMENT ) {
//                return false;
//            }
//            String uri = HttpConstants.HTTP_CLIENT_NS_URI;
//            int fp = node.getNamePool().getFingerprint(uri, "request");
//            return fp == node.getFingerprint();
//        }
//
//        @Override
//        public ItemType getSuperType(TypeHierarchy hierarchy)
//        {
//            return NodeKindTest.ELEMENT;
//        }
//
//        @Override
//        public ItemType getPrimitiveItemType()
//        {
//            return NodeKindTest.ELEMENT;
//        }
//
//        @Override
//        public int getPrimitiveType()
//        {
//            return Type.ELEMENT;
//        }
//
//        @Override
//        public String toString(NamePool pool)
//        {
//            return "element(" + HttpConstants.HTTP_CLIENT_NS_URI + ":reqest)";
//        }
//
//        @Override
//        public AtomicType getAtomizedItemType()
//        {
//            throw new IllegalStateException("Cannot be atomized.");
//        }
//
//        @Override
//        public boolean isAtomizable()
//        {
//            return false;
//        }
//
//        @Override
//        public double getDefaultPriority()
//        {
//            // TODO: I think default priority for element(ns:local) is 0.5.  To
//            // check.
//            return 0.5;
//        }
//
//        @Override
//        public boolean matches(int node_kind, int fingerprint, int annotation)
//        {
//            final String uri = HttpConstants.HTTP_CLIENT_NS_URI;
//            return node_kind == Type.ELEMENT
//                && fingerprint == myConfig.getNamePool().getFingerprint(uri, "request");
//        }
//    }
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
