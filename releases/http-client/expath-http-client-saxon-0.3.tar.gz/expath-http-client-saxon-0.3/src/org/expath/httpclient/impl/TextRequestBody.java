/****************************************************************************/
/*  File:       TextRequestBody.java                                        */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-04                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import java.io.OutputStream;
import java.util.Properties;
import javax.xml.transform.OutputKeys;
import net.sf.saxon.Configuration;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.query.QueryResult;
import net.sf.saxon.trans.XPathException;
import org.expath.httpclient.HeaderSet;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-04
 */
public class TextRequestBody
        extends SinglePartRequestBody
{
    public TextRequestBody(NodeInfo elem)
            throws XPathException
    {
        super(elem);
    }

    @Override
    public void setHeaders(HeaderSet headers)
            throws XPathException
    {
        super.setHeaders(headers);
        // set the Content-Type header (if not set by the user)
        if ( headers.getFirstHeader("Content-Type") == null ) {
            // TODO: When $serial will be taken into account, maybe UTF-8 won't
            // be correct anymore...?
            String type = getContentType() + "; charset=utf-8";
            headers.add("Content-Type", type);
        }
    }

    @Override
    public void serialize(OutputStream out)
            throws XPathException
    {
//        Result dest = new StreamResult(out);
        // TODO: Set serialization options... (enforce UTF-8, ...)
        Properties options = new Properties();
        options.put(OutputKeys.METHOD, "text");
//        for ( NodeInfo child : getChilds() ) {
//            // TODO: QueryResult, really?
//            QueryResult.serialize(child, dest, options);
//        }
        Configuration config = getBodyElement().getConfiguration();
        QueryResult.serializeSequence(getChilds(), config, out, options);
    }
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
