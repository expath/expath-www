/****************************************************************************/
/*  File:       MultipartInputStream.java                                   */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-04                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

/**
 * TODO<doc>: ...
 *
 * TODO: The overall algorithm should be reviewed.  In particular scanning for
 * the boundary.
 *
 * @author Florent Georges
 * @date   2009-02-04
 */
public class MultipartInputStream
        extends InputStream
{
    public MultipartInputStream(InputStream stream, String boundary)
            throws IOException
    {
        if ( stream == null ) {
            throw new IOException("input stream is null");
        }
        if ( boundary == null ) {
            throw new IOException("boundary is null");
        }
        myStream = stream;
        myBuf = new byte[4096];
        myPos = 0;
        myLen = 0;
        myEof = false;
        try {
            myBoundary = boundary.getBytes("US-ASCII");
        }
        catch ( UnsupportedEncodingException ex ) {
            String msg = "INTERNAL ERROR: US-ASCII charset not supported";
            IOException ioex = new IOException(msg);
            ioex.initCause(ex);
            throw ioex;
        }
        myHasBeenInit = false;
        myPartLength = 0;
        myLastError = null;
    }

    @Override
    public int read()
            throws IOException
    {
        if ( myPos == myLen ) {
            feedBuffer();
        }
        if ( myEof ) {
            // DEBUG:
            System.err.println("PART len: " + myPartLength);
            return -1;
        }
        int b = myBuf[myPos++];
        if ( b == NEWLINE[0] ) {
            b = checkBoundary();
        }
        if ( ! myEof ) {
            ++myPartLength;
        }
        else {
            // DEBUG: (contains the header lengths too)
            System.err.println("PART len: " + myPartLength);
        }
        return b;
    }

    public int readAhead()
            throws IOException
    {
        if ( myPos == myLen ) {
            feedBuffer();
        }
        if ( myEof ) {
            return -1;
        }
        int b = myBuf[myPos];
        if ( b == NEWLINE[0] ) {
            b = checkBoundary();
        }
        return b;
    }

    public boolean hasMorePart()
    {
        return ! myLastBoundarySeen;
    }

    public void nextPart()
            throws IOException
    {
        if ( myLastError != null ) {
            throw new IOException(myLastError);
        }
        // FIXME: TODO: ...
        myEof = false;
        myPartLength = 0;
    }

    // FIXME: The first time, skip the first boundary!
    private void feedBuffer()
            throws IOException
    {
        if ( ! myEof ) {
            myLen = myStream.read(myBuf);
            myPos = 0;
            myEof = myLen == -1;
            if ( ! myHasBeenInit ) {
                checkBoundary();
                if ( myPos < 2 ) {
                    myLastError = "content does not start with boundary delimiter";
                    throw new IOException(myLastError);
                }
            }
        }
    }

//    private void DEBUG_LOG_BYTES(String prompt, byte[] b, int start)
//    {
//        StringBuilder buf = new StringBuilder(prompt);
//        buf.append(": ");
//        buf.append(start);
//        buf.append(" - ");
//        for ( int i = 0; start < b.length && i < 20; ++i, ++start ) {
//            if ( b[start] == 10 ) {
//                buf.append("\\n");
//            }
//            else if ( b[start] == 13 ) {
//                buf.append("\\r");
//            }
//            else {
//                byte[] c = { (byte) b[start]};
//                buf.append(new String(c));
//            }
//        }
//        System.err.println(buf);
//        System.err.flush();
//    }

    // TODO<doc>: On a \r, check if this is a boundary.  If it is, skip it, and
    // return the next byte, if not, return the current byte (a \r in every
    // cases.)
    //
    // TODO: Case when the boundary has been only partially read at the end of
    // the buffer not supported yet! (I think tout would require two buffers)
    private int checkBoundary()
            throws IOException
    {
        int i = 0;
        if ( myHasBeenInit ) {
            if ( myBuf[myPos] != NEWLINE[1] ) {
                return NEWLINE[0];
            }
            i = myPos + 1; // because myPos has been advanced yet on \n
        }
        // skip all \r\n
        while ( myBuf[i] == NEWLINE[0] && myBuf[i + 1] == NEWLINE[1] ) {
            i += 2;
        }
        // i is now the first pos after all \r\n
        if ( myBuf[i] != DASH || myBuf[i + 1] != DASH ) {
            return NEWLINE[0];
        }
        i += 2;
        for ( int k = 0; k < myBoundary.length; ++k, ++i ) {
            if ( myBuf[i] != myBoundary[k] ) {
                return NEWLINE[0];
            }
        }
        // last boundary must be followed by "--"
        if ( myBuf[i] == DASH && myBuf[i + 1] == DASH ) {
            i += 2;
            myLastBoundarySeen = true;
        }
        // boundary must be followed by any space then \r\n
        // if it is not -> error
        while ( myBuf[i] == SPACE ) {
            ++i;
        }
        if ( myBuf[i] != NEWLINE[0] || myBuf[i + 1] != NEWLINE[1] ) {
            myEof = true;
            myLastError = "boundary matched but not followed by \\r\\n";
            // FIXME: What the fuck?!  When wrapped into an InputStreamReader,
            // the exception is caught somewhere in its way...
            throw new IOException(myLastError);
        }
        // adjust pos to the next char to read (right after \r\n)
        myPos = i + 2;
        if ( myHasBeenInit ) {
            myEof = true;
        }
        myHasBeenInit = true;
        return -1;
    }

    private InputStream myStream;
    private byte[] myBuf;
    private int myPos;
    private int myLen;
    private boolean myEof;
    private byte[] myBoundary;
    private boolean myHasBeenInit;
    private boolean myLastBoundarySeen = false;
    // DEBUG: For logging purpose...
    private int myPartLength;
    // FIXME: Because the IOException thrown in checkBoundary() is caught!
    private String myLastError;
    private final static byte[] NEWLINE = { 13, 10 }; // "\r\n".getBytes("US-ASCII")
    private final static byte DASH = 45; // "-".getBytes("US-ASCII")[0]
    private final static byte SPACE = 32; // " ".getBytes("US-ASCII")[0]
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
