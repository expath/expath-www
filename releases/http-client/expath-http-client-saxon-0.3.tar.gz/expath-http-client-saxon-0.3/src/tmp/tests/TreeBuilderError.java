/****************************************************************************/
/*  File:       TreeBuilderError.java                                       */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-02                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package tmp.tests;

import net.sf.saxon.Configuration;
import net.sf.saxon.event.PipelineConfiguration;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.tree.TreeBuilder;
import org.expath.httpclient.TreeBuilderHelper;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-02
 */
public class TreeBuilderError
{
    public static String doIt(XPathContext ctxt)
            throws XPathException
    {
        Configuration config = ctxt.getConfiguration();
        PipelineConfiguration pipe = new PipelineConfiguration();
        pipe.setConfiguration(config);

        TreeBuilder b = new TreeBuilder();
        b.setPipelineConfiguration(pipe);
        NamePool pool = config.getNamePool();

        TreeBuilderHelper helper = new TreeBuilderHelper(ctxt);
        helper.startElem("empty");
        helper.startContent();
        helper.endElem();

        return "dummy";
    }
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
