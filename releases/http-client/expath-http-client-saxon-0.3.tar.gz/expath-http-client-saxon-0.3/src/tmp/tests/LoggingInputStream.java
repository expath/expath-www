/****************************************************************************/
/*  File:       LoggingInputStream.java                                     */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-22                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package tmp.tests;

import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.logging.Log;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-22
 */
public class LoggingInputStream
        extends InputStream
{
    public LoggingInputStream(InputStream proxied, Log log) {
        myProxied = proxied;
        myLog = log;
    }
    @Override
    public int read() throws IOException {
        int b = myProxied.read();
        myLog.debug("read(): " + (char) b);
        return b;
    }
    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        int i = myProxied.read(b, off, len);
        myLog.debug("read(byte[],int,int): " + (i < 0 ? "-1" : new String(b, off, i)));
        return i;
    }
    @Override
    public int read(byte[] b) throws IOException {
        int i = myProxied.read(b);
        myLog.debug("read(byte[]): " + (i < 0 ? "-1" : new String(b, 0, i)));
        return i;
    }
    @Override
    public int available() throws IOException {
        myLog.debug("available()");
        return myProxied.available();
    }
    @Override
    public void mark(int i) {
        myLog.debug("mark()");
        myProxied.mark(i);
    }
    @Override
    public boolean markSupported() {
        boolean b = myProxied.markSupported();
        myLog.debug("markSupported(): " + b);
        return b;
    }
    @Override
    public void reset() throws IOException {
        myLog.debug("reset()");
        myProxied.reset();
    }
    @Override
    public long skip(long l) throws IOException {
        long res = myProxied.skip(l);
        myLog.debug("skip(): " + res);
        return res;
    }
    @Override
    public void close() throws IOException {
        myLog.debug("close()");
        myProxied.close();
    }
    private InputStream myProxied;
    private Log myLog;
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
