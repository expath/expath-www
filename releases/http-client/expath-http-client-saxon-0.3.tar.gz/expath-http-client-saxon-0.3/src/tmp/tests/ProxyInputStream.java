package tmp.tests;

import java.io.IOException;
import java.io.InputStream;

/**
 *
 * @author georgfl
 */
public class ProxyInputStream
        extends InputStream
{
    public ProxyInputStream(InputStream proxied) {
        myProxied = proxied;
    }
    public long skip(long n) throws IOException {
        System.err.println("skip(" + n + ")");
        return myProxied.skip(n);
    }
    public synchronized void reset() throws IOException {
        System.err.println("reset()");
        myProxied.reset();
    }
    public int read(byte[] b, int off, int len) throws IOException {
        System.err.println("read(" + b + ", " + off + ", " + len + ")");
        return myProxied.read(b, off, len);
    }
    public int read(byte[] b) throws IOException {
        System.err.println("read(" + b + ")");
        return myProxied.read(b);
    }
    public int read() throws IOException {
        System.err.println("read()");
        return myProxied.read();
    }
    public boolean markSupported() {
        System.err.println("markSupported()");
        return myProxied.markSupported();
    }
    public synchronized void mark(int readlimit) {
        System.err.println("mark(" + readlimit + ")");
        myProxied.mark(readlimit);
    }
    public void close() throws IOException {
        System.err.println("close()");
        myProxied.close();
    }
    public int available() throws IOException {
        System.err.println("available()");
        return myProxied.available();
    }
    private InputStream myProxied;
}
