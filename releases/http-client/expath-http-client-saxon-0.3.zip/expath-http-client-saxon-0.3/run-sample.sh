#!/bin/sh

# EDIT THIS: where did you put Saxon?
SAXON="/.../saxon9-1-0-5j/saxon9.jar"

# EDIT THIS: if you are behind a proxy, uncomment this line and edit
# the values...
# PR="-Dhttp.proxyHost=proxy -Dhttp.proxyPort=8080"

# class path delimiter (':' by default, ';' on Cygwin)
if [[ `uname -o` = "Cygwin" ]]; then
    DELIM=";";
else
    DELIM=":";
fi

# the class path
CP="${SAXON}"
CP="${CP}${DELIM}exslt2-http-client.jar"
CP="${CP}${DELIM}lib/commons-codec-1.3.jar"
CP="${CP}${DELIM}lib/commons-logging-1.1.1.jar"
CP="${CP}${DELIM}lib/httpclient-4.0-beta2.jar"
CP="${CP}${DELIM}lib/httpcore-4.0.jar"
CP="${CP}${DELIM}lib/tagsoup-1.2.jar"

java $PR -cp "$CP" net.sf.saxon.Transform -xsl:sample/simple-get.xsl -it:main

# USER=...
# PWD=...
# java $PR -cp "$CP" net.sf.saxon.Transform -xsl:sample/backup-pim.xsl -it:main user="$USER" pwd="$PWD"
