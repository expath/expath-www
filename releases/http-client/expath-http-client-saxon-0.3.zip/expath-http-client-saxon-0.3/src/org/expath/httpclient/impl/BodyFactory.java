/****************************************************************************/
/*  File:       BodyFactory.java                                            */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-03                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.trans.XPathException;
import org.expath.httpclient.ContentType;
import org.expath.httpclient.HeaderSet;
import org.expath.httpclient.HttpConnection;
import org.expath.httpclient.HttpRequestBody;
import org.expath.httpclient.HttpResponseBody;


/**
 * Factory class for bodies, either in requests or in responses.
 *
 * @author Florent Georges
 * @date   2009-02-03
 */
public class BodyFactory
{
    public static HttpRequestBody makeRequestBody(NodeInfo elem, Item serial)
            throws XPathException
    {
        Type type = parseType(elem);
        if ( type == Type.MULTIPART ) {
            return new MultipartRequestBody(elem, serial);
        }
        else if ( serial != null ) {
            return new SerialRequestBody(elem, serial);
        }
        else if ( type == Type.HREF ) {
            return new HrefRequestBody(elem);
        }
        else if ( type == Type.XML ) {
            return new XmlRequestBody(elem);
        }
        else if ( type == Type.HTML ) {
            return new HtmlRequestBody(elem);
        }
        else if ( type == Type.TEXT ) {
            return new TextRequestBody(elem);
        }
        else if ( type == Type.BINARY ) {
            return new BinaryRequestBody(elem);
        }
        else {
            throw new XPathException("could not happen");
        }
    }

    public static HttpResponseBody makeResponseBody(ContentType type, HttpConnection conn, XPathContext ctxt)
            throws XPathException
    {
        if ( type == null ) {
            // it is legitimate to not have a body in a response; for instance
            // on a "304 Not Modified"
            return null;
        }
        String t = type.getType();
        if ( t == null ) {
            return null;
        }
        InputStream in = conn.getResponseStream();
        // DEBUG:
        // if ( LOG.isDebugEnabled() ) {
        //     in = new LoggingInputStream(in, LOG);
        // }
        if ( t.startsWith("multipart/") ) {
            return new MultipartResponseBody(in, type, conn, ctxt);
        }
        else {
            return makeResponsePart(null, in, type, ctxt);
        }
    }

    // package-level to be used within MultipartResponseBody ctor
    static HttpResponseBody makeResponsePart(HeaderSet headers, InputStream in, ContentType content_type, XPathContext ctxt)
            throws XPathException
    {
        if ( content_type == null ) {
            throw new XPathException("impossible to find the content type");
        }
        String t = content_type.getType();
        if ( t == null ) {
            throw new XPathException("impossible to find the content type");
        }
        Type type = decodeType(content_type.getType());
        if ( type == Type.XML ) {
            // TODO: 'content_type' is the header Content-Type without any param
            // (i.e. "text/xml".)  Should we keep this, or put the whole header
            // (i.e. "text/xml; charset=utf-8")? (and for other types as well...)
            return new XmlResponseBody(in, content_type, headers, ctxt, false);
        }
        else if ( type == Type.HTML ) {
            return new XmlResponseBody(in, content_type, headers, ctxt, true);
        }
        else if ( type == Type.TEXT ) {
            return new TextResponseBody(in, content_type, headers);
        }
        else if ( type == Type.BINARY ) {
            return new BinaryResponseBody(in, content_type, headers);
        }
        else {
            throw new XPathException("INTERNAL ERROR: cannot happen: " + type);
        }
    }

    private static enum Type
    {
        XML,
        HTML,
        TEXT,
        BINARY,
        MULTIPART,
        HREF
    }

    private static Set<String> TEXT_TYPES;
    static {
        TEXT_TYPES = new HashSet<String>();
        TEXT_TYPES.add("application/x-www-form-urlencoded");
        TEXT_TYPES.add("application/xml-dtd");
    }

    private static Set<String> XML_TYPES;
    static {
        // Doc: does not handle "application/xml-dtd" as XML
        // TODO: What about ".../xml-external-parsed-entity" ?
        XML_TYPES = new HashSet<String>();
        XML_TYPES.add("text/xml");
        XML_TYPES.add("application/xml");
        XML_TYPES.add("text/xml-external-parsed-entity");
        XML_TYPES.add("application/xml-external-parsed-entity");
    }

    private static Type decodeType(String type)
    {
        if ( type.startsWith("multipart/") ) {
            return Type.MULTIPART;
        }
        else if ( "text/html".equals(type) ) {
            return Type.HTML;
        }
        else if ( type.endsWith("+xml") || XML_TYPES.contains(type) ) {
            return Type.XML;
        }
        else if ( type.startsWith("text/") || TEXT_TYPES.contains(type) ) {
            return Type.TEXT;
        }
        else {
            return Type.BINARY;
        }
    }

    private static Type parseType(NodeInfo elem)
            throws XPathException
    {
        String local = elem.getLocalPart();
        if ( "multipart".equals(local) ) {
            return Type.MULTIPART;
        }
        else if ( ! "body".equals(local) ) {
            throw new XPathException("INTERNAL ERROR: cannot happen, checked before");
        }
        else {
            if ( SaxonHelper.getAttribute(elem, "href") != null ) {
                return Type.HREF;
            }
            String content_type = SaxonHelper.getAttribute(elem, "content-type");
            if ( content_type == null ) {
                throw new XPathException("@content-type is not set on http:body");
            }
            Type type = decodeType(HeaderSet.getValueWithoutParam(content_type));
            if ( type == Type.MULTIPART ) {
                String msg = "multipart type not allowed for http:body: " + content_type;
                throw new XPathException(msg);
            }
            return type;
        }
    }
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
