/****************************************************************************/
/*  File:       SaxonHelper.java                                            */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-06                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import java.util.Arrays;
import net.sf.saxon.om.Axis;
import net.sf.saxon.om.AxisIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.pattern.NameTest;
import net.sf.saxon.pattern.NodeTest;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.type.Type;
import org.expath.httpclient.HttpConstants;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-06
 */
public class SaxonHelper
{
    /**
     * Return the value of an attribute.
     * 
     * @param elem The element on which the attribute must be set.
     *
     * @param name The local name of the attribute to look for.  The attribute
     * is looked for in no namespace.
     *
     * @return The value of the attribute, or null if it does not exist.
     *
     * @throws XPathException If {@code elem} is null or if it is not an element.
     */
    public static String getAttribute(NodeInfo elem, String name)
            throws XPathException
    {
        // pre-conditions
        if ( elem == null ) {
            throw new XPathException("the node is null");
        }
        if ( elem.getNodeKind() != Type.ELEMENT ) {
            throw new XPathException("the node is not an element");
        }
        // get the attribute
        NamePool pool = elem.getNamePool();
        NodeTest pred = new NameTest(Type.ATTRIBUTE, "", name, pool);
        AxisIterator attrs = elem.iterateAxis(Axis.ATTRIBUTE, pred);
        NodeInfo a = (NodeInfo) attrs.next();
        // return its string value, or null if there is no such attribute
        if ( a == null ) {
            return null;
        }
        else {
            return a.getStringValue();
        }
    }

    /**
     * Check the element {@code elem} does not have attributes other than {@code names}.
     *
     * {@code names} contains non-qualified names, for allowed attributes.  The
     * element can have other attributes in other namespace (not in the HTTP
     * Client namespace) but no attributes in no namespace.
     *
     * @param elem The element to check the attributes on (cannot be null.)
     *
     * @param names The non-qualified names of allowed attributes (cannot be null,
     * but can be empty.)
     * 
     * @throws XPathException If the element contains an attribute in the HTTP
     * Client namespace, or in no namespace and the name of which is not in
     * {@code names}.
     */
    public static void noOtherNCNameAttribute(NodeInfo elem, String[] names)
            throws XPathException
    {
        if ( elem == null || names == null ) {
            throw new NullPointerException("elem and names cannot be null");
        }
        String[] sorted = new String[names.length];
        for ( int i = 0; i < names.length; ++i ) {
            sorted[i] = names[i];
        }
        Arrays.sort(sorted);
        String elem_name = elem.getDisplayName();
        AxisIterator it = elem.iterateAxis(Axis.ATTRIBUTE);
        NodeInfo attr;
        while ( (attr = (NodeInfo) it.next()) != null ) {
            String attr_name = attr.getDisplayName();
            if ( HttpConstants.HTTP_CLIENT_NS_URI.equals(attr.getURI()) ) {
                throw new XPathException("@" + attr_name + " not allowed on " + elem_name);
            }
            else if ( ! "".equals(attr.getURI()) ) {
                // ignore other-namespace-attributes
            }
            else if ( Arrays.binarySearch(sorted, attr.getLocalPart()) < 0 ) {
                throw new XPathException("@" + attr_name + " not allowed on " + elem_name);
            }
        }
    }
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
