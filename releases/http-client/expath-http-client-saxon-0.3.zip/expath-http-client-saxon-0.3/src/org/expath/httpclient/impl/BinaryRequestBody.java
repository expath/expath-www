/****************************************************************************/
/*  File:       BinaryRequestBody.java                                      */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-04                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import java.io.OutputStream;
import java.util.Properties;
import javax.xml.transform.OutputKeys;
import net.sf.saxon.Configuration;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.query.QueryResult;
import net.sf.saxon.trans.XPathException;
import net.iharder.Base64;
import org.expath.httpclient.HeaderSet;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-04
 */
public class BinaryRequestBody
        extends SinglePartRequestBody
{
    public BinaryRequestBody(NodeInfo elem)
            throws XPathException
    {
        super(elem);
    }

    @Override
    public void setHeaders(HeaderSet headers)
            throws XPathException
    {
        super.setHeaders(headers);
        // set the Content-Type header (if not set by the user)
        if ( headers.getFirstHeader("Content-Type") == null ) {
            headers.add("Content-Type", getContentType());
        }
    }

    // Serialize to bytes.  Actually serialize to text, that must be in base64,
    // with a wrapper output stream that decodes the base64 text to bytes on
    // the fly.
    @Override
    public void serialize(OutputStream out)
            throws XPathException
    {
        Properties options = new Properties();
        options.put(OutputKeys.METHOD, "text");
        Configuration config = getBodyElement().getConfiguration();
        OutputStream wrapper = new Base64.OutputStream(out, Base64.DECODE);
        QueryResult.serializeSequence(getChilds(), config, wrapper, options);
    }
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
