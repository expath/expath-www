/****************************************************************************/
/*  File:       MultipartResponseBody.java                                  */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-04                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.trans.XPathException;
import org.apache.http.Header;
import org.expath.httpclient.ContentType;
import org.expath.httpclient.HeaderSet;
import org.expath.httpclient.HttpConnection;
import org.expath.httpclient.HttpResponse;
import org.expath.httpclient.HttpResponseBody;
import org.expath.httpclient.TreeBuilderHelper;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-04
 */
public class MultipartResponseBody
        implements HttpResponseBody
{
    public MultipartResponseBody(InputStream in, ContentType type, HttpConnection conn, XPathContext ctxt)
            throws XPathException
    {
        myContentType = type;
        myParts = new ArrayList<HttpResponseBody>();
        Header h = conn.getResponseHeaders().getFirstHeader("Content-Type");
        if ( h == null ) {
            throw new XPathException("No content type");
        }
        myBoundary = type.getBoundary();
        if ( myBoundary == null ) {
            throw new XPathException("No boundary");
        }
        try {
            MultipartInputStream wrapper = new MultipartInputStream(in, myBoundary);
            for ( int i = 1; wrapper.hasMorePart(); ++i ) {
                HeaderSet headers = readHeaders(wrapper);
                // Should not happen.
                if ( headers.isEmpty() ) {
                    throw new XPathException("No header for part #" + i);
                }
                Header ct = headers.getFirstHeader("Content-Type");
                ContentType part_type = new ContentType(ct);
                myParts.add(BodyFactory.makeResponsePart(headers, wrapper, part_type, ctxt));
                wrapper.nextPart();
            }
        }
        catch ( IOException ex ) {
            throw new XPathException("error reading the response stream", ex);
        }
    }

    public void setResponse(HttpResponse response)
    {
        // nothing
    }

    public void outputBody(TreeBuilderHelper b)
            throws XPathException
    {
        b.startElem("multipart");
        b.attribute("content-type", myContentType.getValue());
        b.attribute("boundary", myBoundary);
        b.startContent();
        for ( HttpResponseBody part : myParts ) {
            part.outputBody(b);
        }
        b.endElem();
    }

    public void addResultItems(List<Item> sequence)
            throws XPathException
    {
        for ( HttpResponseBody part : myParts ) {
            part.addResultItems(sequence);
        }
    }

    private HeaderSet readHeaders(MultipartInputStream in)
            throws XPathException
    {
        try {
            HeaderSet headers = new HeaderSet();
            while ( true ) {
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                boolean seen_r = false;
                int c = 0;
                while ( (c = in.read()) != -1 ) {
                    if ( seen_r && c == 10 ) { // 10 = \n
                        int lwsp = in.readAhead();
                        // A header value can be on several lines, if the first
                        // char on the 2d line is either SPC or TAB.
                        if ( lwsp == 32 || lwsp == 9 ) { // 32 = SPC, 9 = TAB
                            in.read();
                            continue;
                        }
                        else {
                            break;
                        }
                    }
                    if ( !seen_r && c == 13 ) { // 13 = \r
                        seen_r = true;
                    }
                    else {
                        buf.write(c);
                    }
                }
                byte[] bytes = buf.toByteArray();
                if ( bytes.length < 2 ) {
                    break;
                }
                if ( bytes.length == 2 && bytes[0] == 13 && bytes[1] == 10 ) {
                    break;
                }
                String line = new String(bytes, "US-ASCII").trim();
                int colon = line.indexOf(':');
                if ( colon < 1 ) {
                    throw new XPathException("header wrong format: " + line);
                }
                String name = line.substring(0, colon);
                String value = line.substring(colon + 1);
                headers.add(name, value);
            }
            return headers;
        }
        catch ( UnsupportedEncodingException ex ) {
            throw new XPathException("INTERNAL ERROR: encoding US-ASCII not supported");
        }
        catch ( IOException ex ) {
            throw new XPathException("error reading multipart headers", ex);
        }
    }

    private List<HttpResponseBody> myParts;
    private ContentType myContentType;
    private String myBoundary;
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
