/****************************************************************************/
/*  File:       SinglePartRequestBody.java                                  */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-06                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import java.util.ArrayList;
import java.util.List;
import net.sf.saxon.om.ArrayIterator;
import net.sf.saxon.om.Axis;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.trans.XPathException;
import org.expath.httpclient.HeaderSet;
import org.expath.httpclient.HttpRequestBody;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-06
 */
public abstract class SinglePartRequestBody
        extends HttpRequestBody
{
    public SinglePartRequestBody(NodeInfo elem)
            throws XPathException
    {
        super(elem);
        String[] attr_names = { "content-type", "encoding", "id", "description", "href" };
        myEncoding = SaxonHelper.getAttribute(elem, attr_names[1]);
        // TODO: @encoding not supported yet...
        if ( myEncoding != null ) {
            throw new XPathException("TODO: @encoding not supported yet...");
        }
        myId = SaxonHelper.getAttribute(elem, attr_names[2]);
        myDesc = SaxonHelper.getAttribute(elem, attr_names[3]);
        // check for not allowed attributes
        SaxonHelper.noOtherNCNameAttribute(elem, attr_names);
        // handle childs
        List<Item> childs = new ArrayList<Item>();
        SequenceIterator it = getBodyElement().iterateAxis(Axis.CHILD);
        Item item;
        while ( (item = it.next()) != null ) {
            childs.add(item);
        }
        myChilds = childs.toArray(new Item[1]);
    }

    public String getEncoding()
    {
        return myEncoding;
    }

    public String getId()
    {
        return myId;
    }

    public String getDescription()
    {
        return myDesc;
    }

    public SequenceIterator getChilds()
    {
        Item[] array = myChilds;
        if ( getContent() != null ) {
            array = new Item[1];
            array[0] = getContent();
        }
        return new ArrayIterator(array);
    }

    @Override
    public void setHeaders(HeaderSet headers)
            throws XPathException
    {
        // NOTE: Content-Type must be set by the final classes...

        // TODO: @encoding not supported yet...

        // set the Content-ID header (if not set by the user)
        if ( myId != null && headers.getFirstHeader("Content-ID") == null ) {
            headers.add("Content-ID", myId);
        }
        // set the Content-Description header (if not set by the user)
        if ( myDesc != null && headers.getFirstHeader("Content-Description") == null ) {
            headers.add("Content-Description", myDesc);
        }
    }

    @Override
    public boolean isMultipart()
    {
        return false;
    }

    private String myEncoding;
    private String myId;
    private String myDesc;
    private Item[] myChilds;
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
