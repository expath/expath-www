/****************************************************************************/
/*  File:       TreeBuilderHelper.java                                      */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-02                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient;

import net.sf.saxon.event.Builder;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.trans.XPathException;
import org.apache.http.Header;


/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-02
 */
public class TreeBuilderHelper
{
    public TreeBuilderHelper(XPathContext ctxt)
            throws XPathException
    {
        myBuilder = ctxt.getController().makeBuilder();
        myNamePool = ctxt.getConfiguration().getNamePool();
        myBuilder.open();
    }

    public void outputHeaders(HeaderSet headers)
            throws XPathException
    {
        outputHeaders(myBuilder, myNamePool, headers);
    }

    public NodeInfo getCurrentRoot()
            throws XPathException
    {
        myBuilder.close();
        return myBuilder.getCurrentRoot();
    }

    public void startElem(String localname)
            throws XPathException
    {
        startElem(myBuilder, myNamePool, localname);
    }

    public void attribute(String localname, CharSequence value)
            throws XPathException
    {
        attribute(myBuilder, myNamePool, localname, value);
    }

    public void startContent()
            throws XPathException
    {
        startContent(myBuilder);
    }

    public void endElem()
            throws XPathException
    {
        endElem(myBuilder);
    }

    public static void outputHeaders(Builder b, NamePool pool, HeaderSet headers)
            throws XPathException
    {
        for ( Header h : headers ) {
            assert h.getName() != null : "Header name cannot be null";
            startElem(b, pool, "header");
            attribute(b, pool, "name", h.getName());
            attribute(b, pool, "value", h.getValue());
            startContent(b);
            endElem(b);
        }
    }

    public static void startElem(Builder b, NamePool pool, String localname)
            throws XPathException
    {
        final String prefix = HttpConstants.HTTP_CLIENT_NS_PREFIX;
        final String uri = HttpConstants.HTTP_CLIENT_NS_URI;
        int code = pool.allocate(prefix, uri, localname);
        b.startElement(code, -1, 0, 0);
    }

    public static void attribute(Builder b, NamePool pool, String localname, CharSequence value)
            throws XPathException
    {
        if ( value != null ) {
            int code = pool.allocate("", "", localname);
            b.attribute(code, -1, value, 0, 0);
        }
    }

    public static void startContent(Builder b)
            throws XPathException
    {
        b.startContent();
    }

    public static void endElem(Builder b)
            throws XPathException
    {
        b.endElement();
    }

    private Builder myBuilder;
    private NamePool myNamePool;
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
