package tmp.tests;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentProducer;
import org.apache.http.entity.EntityTemplate;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

/**
 * My initial test.
 */
public class ApacheEntityProducer
{
    public static void main(String[] args)
            throws IOException
    {
        // the entity
        EntityTemplate entity = new EntityTemplate(
                new StringProducer("<content/>"));
        entity.setContentType("application/xml");
        // StringEntity entity = new StringEntity("<content/>");
        // the method
        HttpPost post = new HttpPost(URI);
        post.setEntity(new EntityProxy(entity));
        // send it
        HttpClient client = new DefaultHttpClient();
        client.execute(post).getEntity().writeTo(System.err);
    }

    private static final String URI = "http://localhost:8079/";

    private static class StringProducer
            implements ContentProducer
    {
        public StringProducer(String content) {
            myContent = content.getBytes();
        }
        public void writeTo(OutputStream out) throws IOException {
            out.write(myContent);
        }
        private byte[] myContent;
    }

    // the proxy class, to trace calls to the entity object
    private static class EntityProxy
            implements HttpEntity
    {
        public EntityProxy(HttpEntity proxied) {
            myProxied = proxied;
        }
        public boolean isRepeatable() {
            boolean b = myProxied.isRepeatable();
            System.err.println("isRepeatable(): " + b);
            return b;
        }
        public boolean isChunked() {
            boolean b = myProxied.isChunked();
            System.err.println("isChunked(): " + b);
            return b;
        }
        public long getContentLength() {
            long l = myProxied.getContentLength();
            System.err.println("getContentLength(): " + l);
            return l == -1 ? 10 : l;
        }
        public Header getContentType() {
            Header h = myProxied.getContentType();
            System.err.println("getContentType(): " + h);
            return h;
        }
        public Header getContentEncoding() {
            Header h = myProxied.getContentEncoding();
            System.err.println("getContentEncoding(): " + h);
            return h;
        }
        public InputStream getContent() throws IOException, IllegalStateException {
            System.err.println("getContent()");
            return myProxied.getContent();
        }
        public void writeTo(OutputStream outstream) throws IOException {
            System.err.println("writeTo()");
            myProxied.writeTo(outstream);
        }
        public boolean isStreaming() {
            boolean b = myProxied.isStreaming();
            System.err.println("isStreaming(): " + b);
            return b;
        }
        public void consumeContent() throws IOException {
            System.err.println("consumeContent()");
            myProxied.consumeContent();
        }
        private HttpEntity myProxied;
    }

    static {
        System.setProperty("org.apache.commons.logging.Log",
                "org.apache.commons.logging.impl.SimpleLog");
        System.setProperty(
                "org.apache.commons.logging.simplelog.log.org.apache.http",
                "debug");
    }
}
