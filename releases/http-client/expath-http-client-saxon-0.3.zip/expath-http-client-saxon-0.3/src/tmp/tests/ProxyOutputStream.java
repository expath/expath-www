package tmp.tests;

// TODO: It seems that a close is done somewhere (Saxon serialization?)

import java.io.IOException;
import java.io.OutputStream;

// and that close the socket (closing either input or output seems to
// automatically close both and the socket.) !!!
// This is to investigate...
public class ProxyOutputStream
        extends OutputStream
{
    public ProxyOutputStream(OutputStream proxied) {
        myProxied = proxied;
    }
    public void write(byte[] b, int off, int len) throws IOException {
        System.err.println("write(3)");
        myProxied.write(b, off, len);
    }
    public void write(byte[] b) throws IOException {
        System.err.println("write(2)");
        myProxied.write(b);
    }
    public void write(int b) throws IOException {
        System.err.println("write(1)");
        myProxied.write(b);
    }
    public void flush() throws IOException {
        System.err.println("flush()");
        myProxied.flush();
    }
    public void close() throws IOException {
        System.err.println("close()");
        try {
            throw new Exception("DEBUG: JUST TO GET STACKTRACE!");
        }
        catch ( Exception ex ) {
            ex.printStackTrace();
        }
        myProxied.close();
    }
    private OutputStream myProxied;
}
